==========
User Guide
==========

.. toctree::
   :numbered: 
   :maxdepth: 3

   introduction
   download
   installation
   build
   usage
   mathematics
   bestPractice
   development
   notation
   help
   glossary
   acknowledgments
   disclaimer
   legal
