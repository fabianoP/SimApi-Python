/* Copyright (c) 1998, 1999 Thai Open Source Software Center Ltd
   See the file COPYING for copying permission.
*/

int codepageMap(int cp, int *map);
int codepageConvert(int cp, const char *p);
